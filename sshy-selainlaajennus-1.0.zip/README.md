<meta charset="utf-8">

<h1>Käyttöliittymäparannuksia SSHY:n jäsensivuille</h1>

Ohjelma lisää seuraavat asiat SSHY:n jäsensivuihin (kuvasivuille):
<p>

Hiiren kakkosnäppäintä klikkaamalla saa valikon jossa on toiminnot:
<ol>
<li>Kuvan suurentaminen ja pienentäminen. Kuvan kokoa voi muuttaa 20% kerrallaan. Toimii myös hiiren rullalla.
<li>Kuvan kääntäminen 90 astetta myötä- tai vastapäivään.
<li>Alkuperäisen kuvan (koko ja asento) palauttaminen
<li>Lähdeviitteen generointi. Kuten digihakemistossa, lähdeviite-linkki on myös sivun yläreunassa. Lähdeviitteestä puuttuu sivunumero, koska sitä ei ole SSHY:n sivulla.
</ol>

Lisäksi:
<ol>
<li>Kuvaa voi siirtää hiirellä raahaamalla.
<li>Kuva pysyy samassa paikassa siirryttäessä edelliselle tai seuraavalle sivulle. Etua esim. muuttokirjoja luettaessa, jolloin mielenkiintoinen sivu on yleensä oikeassa reunassa.
<li>Kuvan koko ja asento säilyy myös siirryttäessä edelliselle tai seuraavalle sivulle.
<li>Sivun alareunassa olevat toiminnot ovat nyt aina näkyvissä.
</ol>

<font size=smaller>Tekijä: Kari Kujansuu (kari.kujansuu@gmail.com)</font>